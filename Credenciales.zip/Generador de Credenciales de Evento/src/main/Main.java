package main;

import Data.Credencial;
import Data.GestorCredenciales;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        GestorCredenciales gestor = GestorCredenciales.getInstancia();

        Credencial plantilla = new Credencial("Nombre","Cargo","RUT");
        gestor.setPlantilla(plantilla);

        int opcion;
        do {
            System.out.println("\n--- Menú ---");
            System.out.println("1.Crear credencial");
            System.out.println("2.Salir");
            System.out.print("Seleccione opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Cargo: ");
                    String cargo = scanner.nextLine();
                    System.out.print("RUT: ");
                    String rut = scanner.nextLine();
                    Credencial c = gestor.crearCredencial(nombre, cargo, rut);
                    if (c != null) {
                        System.out.println("Credencial creada \n");
                        System.out.println("--------------");
                        c.mostrar();
                        System.out.println("--------------");
                    }
                }
                case 2 -> System.out.println("Saliendo");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 2);
    }
}
