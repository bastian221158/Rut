package Data;

public class GestorCredenciales {
    private static GestorCredenciales instancia;
    private Credencial plantilla;

    private GestorCredenciales() {}

    public static GestorCredenciales getInstancia() {
        if (instancia == null)
            instancia = new GestorCredenciales();
        return instancia;
    }

    public void setPlantilla(Credencial plantilla) {
        this.plantilla = plantilla;
    }

    public Credencial crearCredencial(String nombre, String cargo, String rut) {
        if (plantilla == null) {
            System.out.println("Plantilla no definida.");
            return null;
        }
        Credencial nueva = plantilla.clonar();
        nueva.setNombre(nombre);
        nueva.setCargo(cargo);
        nueva.setRut(rut);
        return nueva;
    }
}
